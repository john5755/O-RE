-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a504.p.ssafy.io    Database: oredb
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content_value` longtext COLLATE utf8mb4_unicode_ci,
  `is_table` bit(1) NOT NULL,
  `page_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1lv6h7cjxydrlm7fjy8ncp75k` (`page_id`),
  CONSTRAINT `FK1lv6h7cjxydrlm7fjy8ncp75k` FOREIGN KEY (`page_id`) REFERENCES `page` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (11,'{\"type\":\"text\",\"name\":\"텍스트\",\"tagProps\":{\"header\":\"아래 양식에 맞춰 기입해주세요.\",\"style\":{\"width\":\"\",\"height\":\"\",\"fontSize\":\"30px\",\"fontWeight\":\"600\"}}}',_binary '\0',6),(12,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"신청자\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',6),(13,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"신청 사유\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',6),(14,'{\"type\":\"date picker\",\"name\":\"날짜\",\"tagProps\":{\"type\":\"date\",\"header\":\"휴가 시작일\",\"style\":{\"width\":\"200px\",\"height\":\"\",\"fontSize\":\"13px\",\"fontWeight\":\"600\"}}}',_binary '\0',6),(15,'{\"type\":\"date picker\",\"name\":\"날짜\",\"tagProps\":{\"type\":\"date\",\"header\":\"휴가 종료일\",\"style\":{\"width\":\"200px\",\"height\":\"\",\"fontSize\":\"13px\",\"fontWeight\":\"600\"}}}',_binary '\0',6),(16,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"업무 대체자\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',6),(17,'{\"type\":\"text\",\"name\":\"텍스트\",\"tagProps\":{\"header\":\"아래 양식에 맞춰 기입해주세요.\",\"style\":{\"width\":\"\",\"height\":\"\",\"fontSize\":\"30px\",\"fontWeight\":\"600\"}}}',_binary '\0',7),(18,'{\"type\":\"text\",\"name\":\"텍스트\",\"tagProps\":{\"header\":\"내용\",\"style\":{\"width\":\"\",\"height\":\"\",\"fontSize\":\"30px\",\"fontWeight\":\"600\"}}}',_binary '\0',8),(19,'{\"type\":\"table\",\"name\":\"테이블\",\"tagProps\":{\"header\":\"휴가신청 목록\",\"title\":[\"신청 사유\",\"휴가 시작일\",\"신청자\",\"업무 대체자\",\"휴가 종료일\"],\"data\":[[\"휴양\",\"2022-11-22\",\"유동윤\",\"김민지\",\"2022-11-23\"]],\"style\":{\"width\":\"100px\",\"height\":\"100px\",\"borderCollapse\":\"collapse\"}}}',_binary '',9),(20,'{\"type\":\"text\",\"name\":\"텍스트\",\"tagProps\":{\"header\":\"기간: 11월 28일 - 12월 2일 \",\"style\":{\"width\":\"\",\"height\":\"\",\"fontSize\":\"30px\",\"fontWeight\":\"600\"}}}',_binary '\0',10),(21,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"월요일\",\"name\":\"\",\"label\":[\"자율출퇴근제\",\"재택근무\",\"기타(휴가 등)\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',10),(22,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"화요일\",\"name\":\"\",\"label\":[\"자율출퇴근제\",\"재택근무\",\"기타(휴가 등)\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',10),(23,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"수요일\",\"name\":\"\",\"label\":[\"자율출퇴근제\",\"재택근무\",\"기타(휴가 등)\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',10),(24,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"목요일\",\"name\":\"\",\"label\":[\"자율출퇴근제\",\"재택근무\",\"기타(휴가 등)\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',10),(25,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"금요일\",\"name\":\"\",\"label\":[\"자율출퇴근제\",\"재택근무\",\"기타(휴가 등)\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',10),(26,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"일정명\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',17),(27,'{\"type\":\"date picker\",\"name\":\"날짜\",\"tagProps\":{\"type\":\"date\",\"header\":\"날짜\",\"style\":{\"width\":\"200px\",\"height\":\"\",\"fontSize\":\"13px\",\"fontWeight\":\"600\"}}}',_binary '\0',17),(28,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"시간\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',17),(29,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"장소\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',17),(30,'{\"type\":\"radio button\",\"name\":\"단일 선택\",\"tagProps\":{\"type\":\"radio\",\"header\":\"참석인원\",\"name\":\"\",\"label\":[\"전원필참\",\"담당자만\",\"자율\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',17),(31,'{\"type\":\"table\",\"name\":\"테이블\",\"tagProps\":{\"header\":\"차주 일정 안내\",\"title\":[\"시간\",\"일정명\",\"날짜\",\"참석인원\",\"장소\"],\"data\":[[\"10:00\",\"주간회의\",\"2022-11-28\",\"전원필참\",\"온라인 Zoom\"],[\"13:00\",\"신사업워크숍\",\"2022-11-30\",\"담당자만\",\"1202 회의실\"]],\"style\":{\"width\":\"100px\",\"height\":\"100px\",\"borderCollapse\":\"collapse\"}}}',_binary '',18),(32,'{\"type\":\"table\",\"name\":\"테이블\",\"tagProps\":{\"header\":\"테이블 제목\",\"title\":[],\"data\":[],\"style\":{\"width\":\"100px\",\"height\":\"100px\",\"borderCollapse\":\"collapse\"}}}',_binary '',19),(33,'{\"type\":\"text\",\"name\":\"텍스트\",\"tagProps\":{\"header\":\"다음 주에 재택근무, 자율출퇴근하시는 분들은 하단 내용 작성해서 제출해주세요\",\"style\":{\"width\":\"\",\"height\":\"\",\"fontSize\":\"30px\",\"fontWeight\":\"600\"}}}',_binary '\0',20),(34,'{\"type\":\"input\",\"name\":\"입력\",\"tagProps\":{\"header\":\"이름\",\"placeholder\":\"내용을 입력하세요\",\"style\":{\"width\":\"250px\",\"height\":\"40px\"}}}',_binary '\0',20),(35,'{\"type\":\"date picker\",\"name\":\"날짜\",\"tagProps\":{\"type\":\"date\",\"header\":\"날짜\",\"style\":{\"width\":\"200px\",\"height\":\"\",\"fontSize\":\"13px\",\"fontWeight\":\"600\"}}}',_binary '\0',20),(36,'{\"type\":\"check box\",\"name\":\"체크박스\",\"tagProps\":{\"type\":\"checkbox\",\"header\":\"근무형태\",\"label\":[\"재택\",\"자율출퇴근\",\"휴가\"],\"style\":{\"width\":\"\",\"height\":\"\"}}}',_binary '\0',20);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:57:26
