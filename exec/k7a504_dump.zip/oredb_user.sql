-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a504.p.ssafy.io    Database: oredb
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (33,'ydy1107@naver.com','유동윤','관리자','$2a$10$4DLRashlzE65BUb67IH/TevGW7oiAEbrzObNlL1acpjmZ..1Hwldy','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/ore_2022-11-20-13-18-16-045_%EC%A6%9D%EB%AA%85%EC%82%AC%EC%A7%84_160_200.jpg','OWNER'),(34,'pms9116@naver.com','박민석','법무팀_팀장','$2a$10$gEyShuZjDLJnPuMc.ST11eAEapmOXq3D5YVI8vg5mLHShidhswGN.','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/ore_2022-11-20-13-23-05-772_%5B%ED%81%AC%EA%B8%B0%EB%B3%80%ED%99%98%5D%EC%A6%9D%EC%82%AC.jpg','USER'),(35,'whiterisi@naver.com','김민지','사업기획팀_팀장','$2a$10$x6s2g8y6FSp0SrInET9ijeiFBoaiPHHT8gbuJoRmOA0OmnQUkUFNa','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/ore_2022-11-20-13-16-16-296_image%20%284%29.png','ADMIN'),(36,'john5755@naver.com','이창엽','인사팀_팀장','$2a$10$tXWrgJyylOKkXzxo/dro5OnnEqBLtJqX0LGbtVPoL0O1R0JGoN71O','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/image+(2).png','ADMIN'),(37,'qldtn8@naver.com','노수빈','IT팀_팀장','$2a$10$UywyXKeM0JeLpY50rL7s/uLeui7bcZj3YMmfj/l0zjUJHzEWAhj7W','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/image+(1).png','ADMIN'),(38,'test1@naver.com','김유진','법무팀_차장','$2a$10$CpUc9S7g1t0ZAbLO68bGueRDOYX4NlhlP6j2kV1kGhJ.Bh2Piah7O','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(39,'test2@naver.com','강한슬','법무팀_과장','$2a$10$on8c3vYo5ob0UWxlOLREreqPyA/a8pLmMWiTasYZ7JAotXuxRxfeG','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER'),(40,'test3@naver.com','박재은','인사팀_대리','$2a$10$9s0S/gH8QNod/uW7zrG8WOz.nfcDwIUAIOAxb7UxefMnxgRIOpKue','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(41,'test4@naver.com','한원영','인사팀_과장','$2a$10$pqWJxOTUw6Gny2ecQmXmIO4x0oloMicCPM5TqKB/E3lTgGJLKGsWi','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member2.png','USER'),(42,'test5@naver.com','함재영','사업기획팀_사원','$2a$10$g8hrnKGHlchjJPf2xgR0AOvmvyG0NuY7BvQRu6eEkg.7AxLcjVKT2','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(43,'test6@naver.com','이해성','사업기획팀_대리','$2a$10$VBCVlHwjgJXZhKjOHQP7ieAPP3kElGrjDM40zJsWZUDnRQCTstllK','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member3.png','USER'),(44,'test7@naver.com','조경재','사업기획팀_차장','$2a$10$pnxE/8tXPBQR9UxvOyHakeS/BxH.KKDFcpiBG/EbOCJsomHwYQJj2','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER'),(45,'test8@naver.com','김건엽','법무팀_과장','$2a$10$fKZ2.djH8R.uctPprvk49.WgTxRQj6ghW3PA45B2pfLOKswfVcBXe','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member2.png','USER'),(46,'test9@naver.com','정해성','IT팀_대리','$2a$10$fNakrvlTVDEUgdK3irVL7OaXbxl26Y7ixNy38rnCkOoxAnWkhDBGy','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(47,'test10@naver.com','강해인','마케팅팀_대리','$2a$10$FFn4QbxysuYnOlqGVgDkwuJ5ynY4RQuKEez500oyoy.doSaXKNhf2','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER'),(48,'test11@naver.com','박민지','인사팀_차장','$2a$10$Buf2QvffTLbSxkI8HJd2mOnLLZuPKrW1bH26HgG8HbIqWXdMUgzEO','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member3.png','USER'),(49,'test12@naver.com','강학현','사무팀_과장','$2a$10$WRC8biIeJoQ.wJ.XASYVxOzJdI0lIahps0.iM1xSitQD4kU5VaVeW','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(50,'test13@naver.com','김민오','재무팀_사원','$2a$10$QRR5.k.FLr0cY0CyuWtxAeVSXiMDRlGqtwHVtLMl7QF0onP5HKGwC','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER'),(51,'test14@naver.com','정승아','사업기획팀_사원','$2a$10$Duae.L7F8rBH6mV5kLSXA.8s8eFQIOd.M4xFSuO/8XHNYYtg7nuba','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(52,'test15@naver.com','김수연','재무팀_차장','$2a$10$wM36wa6TIuMO4PXoKY4dvuVYYskjiG/jG2NihXBomSy6MQevQ5XU6','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member2.png','USER'),(53,'test16@naver.com','강현일','회계팀_사원','$2a$10$geC9v8exivlYweIlrPwxfe.Wl9wtUxgLDKH.JiEyiwZ890tqDqptK','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER'),(54,'test17@naver.com','박수형','회계팀_대리','$2a$10$0kdobN4RYup1r55Yvp9QBOSZZQklK17f9VaWSlQ2Yr2mfVGWbp5M6','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','USER'),(55,'test18@naver.com','이재선','사업기획팀_사원','$2a$10$IoTgtHSEjjB1XHgXAFDK9efFkswKudTyPPu/G8kEpbSD9Db.HwApC','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member3.png','ADMIN'),(56,'test19@naver.com','박선우','사업기획팀_사원','$2a$10$kKmlmnQ3GPbmBiLPqZEFE.MlHmc.BQj1a2SkXKOkQBbZjTFM9kzHS','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/admin.png','ADMIN'),(57,'test20@naver.com','김선정','사업기획팀_대리','$2a$10$OpFqLng1G3iVRjk8x4ucW.fyBvS6M8h0O19RuaqyftJVwHGJZoBzq','https://ore-s3.s3.ap-northeast-2.amazonaws.com/user/member1.png','USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:57:26
