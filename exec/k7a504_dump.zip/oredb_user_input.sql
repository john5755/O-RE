-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a504.p.ssafy.io    Database: oredb
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_input`
--

DROP TABLE IF EXISTS `user_input`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_input` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `input_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `input_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_id` bigint DEFAULT NULL,
  `page_user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK96nav1spvjmmtcqop5ut0oq00` (`page_id`),
  KEY `FK6xqlmoej3973egr8d89e9j8t9` (`page_user_id`),
  CONSTRAINT `FK6xqlmoej3973egr8d89e9j8t9` FOREIGN KEY (`page_user_id`) REFERENCES `page_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK96nav1spvjmmtcqop5ut0oq00` FOREIGN KEY (`page_id`) REFERENCES `page` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_input`
--

LOCK TABLES `user_input` WRITE;
/*!40000 ALTER TABLE `user_input` DISABLE KEYS */;
INSERT INTO `user_input` VALUES (3,'2022-11-20 13:10:06','{\"신청자\":\"유동윤\",\"신청 사유\":\"휴양\",\"휴가 시작일\":\"2022-11-22\",\"휴가 종료일\":\"2022-11-23\",\"업무 대체자\":\"김민지\"}',6,22),(4,'2022-11-20 13:59:46','{\"일정명\":\"주간회의\",\"날짜\":\"2022-11-28\",\"시간\":\"10:00\",\"참석인원\":\"전원필참\",\"장소\":\"온라인 Zoom\"}',17,33),(5,'2022-11-20 14:00:40','{\"일정명\":\"신사업워크숍\",\"날짜\":\"2022-11-30\",\"시간\":\"13:00\",\"장소\":\"1202 회의실\",\"참석인원\":\"담당자만\"}',17,33);
/*!40000 ALTER TABLE `user_input` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:57:25
