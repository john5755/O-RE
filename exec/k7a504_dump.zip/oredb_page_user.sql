-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: k7a504.p.ssafy.io    Database: oredb
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `page_user`
--

DROP TABLE IF EXISTS `page_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_user_role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK63gg97xjdykm7yavv5lq1ttkj` (`page_id`),
  KEY `FKdbrkjlst22ybboih853p8u6y6` (`user_id`),
  CONSTRAINT `FK63gg97xjdykm7yavv5lq1ttkj` FOREIGN KEY (`page_id`) REFERENCES `page` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKdbrkjlst22ybboih853p8u6y6` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_user`
--

LOCK TABLES `page_user` WRITE;
/*!40000 ALTER TABLE `page_user` DISABLE KEYS */;
INSERT INTO `page_user` VALUES (22,'OWNER',6,33),(23,'OWNER',7,33),(24,'OWNER',8,33),(25,'OWNER',9,33),(26,'OWNER',10,33),(27,'MAINTAINER',10,35),(32,'OWNER',17,33),(33,'MAINTAINER',17,35),(34,'OWNER',18,33),(35,'MAINTAINER',18,35),(36,'VIEWER',18,42),(37,'VIEWER',18,43),(38,'VIEWER',18,44),(39,'OWNER',19,33),(40,'MAINTAINER',19,35),(41,'VIEWER',10,34),(42,'VIEWER',10,37),(43,'VIEWER',18,37),(45,'OWNER',20,33),(46,'MAINTAINER',20,35);
/*!40000 ALTER TABLE `page_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 23:57:26
